package com.example.victorious.kindermath;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View.OnClickListener;

public class MathQuiz extends AppCompatActivity {

    //alert dialog for user to register
    final Context context = this;
    private Button button;
    private EditText result;

    private static final String TAG = "MathQuiz";
    private static final String KEY_INDEX = "index";

    //declaraton of variables for math quiz
    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;
    private TextView mQuestionTextView;

    //declaration of button for calculator
    Button button0, button1, button2, button3, button4, button5, button6,
            button7, button8, button9, buttonAdd, buttonSub, buttonDivision,
            buttonMul, button10, buttonC, buttonEqual;
    EditText exampleEditText;

    //to store two values for math operations
    float mValueOne, mValueTwo;

    boolean exampleAddition, mSubtract, exampleMultiplication, exampleDivision;

    //to display question
    private Question[] mQuestionBank = new Question[]{
            new Question(R.string.question_first, true),
            new Question(R.string.question_second, false),
            new Question(R.string.question_third, true),
            new Question(R.string.question_fourth,false),
            new Question(R.string.question_fifth,false),
            new Question(R.string.question_sixth,true),
            new Question(R.string.question_seventh,false),
            new Question(R.string.question_eighth,true),
            new Question(R.string.question_ninth,true),
            new Question(R.string.question_tenth,false),
    };

    private int mCurrentIndex = 0;

    //display different question according to index
    private void updateQuestion(){
        int question = mQuestionBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
    }
    //check answer
    private void checkAnswer(boolean userPressedTrue){
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();

        int messageRedId = 0;

        if(userPressedTrue==answerIsTrue){
            messageRedId = R.string.correct_toast;
        }else{
            messageRedId = R.string.incorrect_toast;
        }

        Toast.makeText(this,messageRedId, Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_math_quiz);

        mQuestionTextView = (TextView)findViewById(R.id.question_text_view);

        mTrueButton = (Button) findViewById(R.id.true_button);
        mTrueButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //call a toast msg to display when correct
                checkAnswer(true);
            }
        });

        mFalseButton = (Button) findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //call a toast msg to display when incorrect
                checkAnswer(false);
            }
        });

        mNextButton = (Button) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mCurrentIndex = (mCurrentIndex + 1)% mQuestionBank.length;
                updateQuestion();
            }
        });

        if (savedInstanceState !=null){
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0);
        }

        updateQuestion();
        //set button id from xml for each button
        button0 = (Button) findViewById(R.id.button0);
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);
        button10 = (Button) findViewById(R.id.button10);
        buttonAdd = (Button) findViewById(R.id.buttonadd);
        buttonSub = (Button) findViewById(R.id.buttonsub);
        buttonMul = (Button) findViewById(R.id.buttonmul);
        buttonDivision = (Button) findViewById(R.id.buttondiv);
        buttonC = (Button) findViewById(R.id.buttonC);
        buttonEqual = (Button) findViewById(R.id.buttoneql);
        exampleEditText = (EditText) findViewById(R.id.edt1);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "2");
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "3");
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "4");
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "5");
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "6");
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "7");
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "8");
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "9");
            }
        });

        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + "0");
            }
        });
        //add function call when button click
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (exampleEditText == null) {
                    exampleEditText.setText("");
                } else {
                    mValueOne = Float.parseFloat(exampleEditText.getText() + "");
                    exampleAddition = true;
                    exampleEditText.setText(null);
                }
            }
        });
        //subtraction function call when button click
        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mValueOne = Float.parseFloat(exampleEditText.getText() + "");
                mSubtract = true;
                exampleEditText.setText(null);
            }
        });
        //multiplication function call when button click
        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mValueOne = Float.parseFloat(exampleEditText.getText() + "");
                exampleMultiplication = true;
                exampleEditText.setText(null);
            }
        });
        //division function call when button click
        buttonDivision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mValueOne = Float.parseFloat(exampleEditText.getText() + "");
                exampleDivision = true;
                exampleEditText.setText(null);
            }
        });
        //display equal answer when click
        buttonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mValueTwo = Float.parseFloat(exampleEditText.getText() + "");
                //function for add, sub, mul and div
                if (exampleAddition == true) {
                    exampleEditText.setText(mValueOne + mValueTwo + "");
                    exampleAddition = false;
                }

                if (mSubtract == true) {
                    exampleEditText.setText(mValueOne - mValueTwo + "");
                    mSubtract = false;
                }

                if (exampleMultiplication == true) {
                    exampleEditText.setText(mValueOne * mValueTwo + "");
                    exampleMultiplication = false;
                }

                if (exampleDivision == true) {
                    exampleEditText.setText(mValueOne / mValueTwo + "");
                    exampleDivision = false;
                }
            }
        });
        //clear the text
        buttonC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText("");
            }
        });
        //display point
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exampleEditText.setText(exampleEditText.getText() + ".");
            }
        });

        //register button and display result text field
        button = (Button) findViewById(R.id.buttonPrompt);
        result = (EditText) findViewById(R.id.editTextResult);

        // add button listener
        button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                // get popup_custom.xml view
                LayoutInflater li = LayoutInflater.from(context);
                View promptsView = li.inflate(R.layout.popup_custom, null);

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                        context);

                // set popup_custom.xml to alertdialog builder
                alertDialogBuilder.setView(promptsView);

                final EditText userInput = (EditText) promptsView
                        .findViewById(R.id.editTextDialogUserInput);

                // set dialog message
                alertDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,int id) {
                                        // get user input and set it to the result at below
                                        result.setText(userInput.getText());
                                    }
                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,int id) {
                                        //cancel the dialog
                                        dialog.cancel();
                                    }
                                });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.show();

            }
        });


    }

    @Override
    public void onSaveInstanceState (Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG, "onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);
    }





}
